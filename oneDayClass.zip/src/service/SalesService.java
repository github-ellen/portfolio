package service;

import java.util.List;
import java.util.Map;

import model.SalesDAO;
import model.SalesDTO;

public class SalesService {
	SalesDAO sdao = new SalesDAO();
	
	public int insert(SalesDTO sdto) {
		return sdao.insert(sdto);
	}

	public List<Map<String,Object>> selectList_detail(Map<String, String> findMap) {
		return  sdao.selectList_detail(findMap);
		
	}

	public List<Map<String,Object>> selectList(Map<String, String> findMap) {
		return  sdao.selectList(findMap);
		
	}
	
}
