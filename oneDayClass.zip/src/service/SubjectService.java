package service;

import java.util.List;
import java.util.Map;

import model.SubjectDAO;
import model.SubjectDTO;

public class SubjectService {
	SubjectDAO sDAO = new SubjectDAO(); 
	public int insert(SubjectDTO sdto) {
		return sDAO.insert(sdto);
	}
        public List<Map<String, Object>> selectList(Map<String, String> findMap) {
                return sDAO.selectList(findMap);
        }
}
