package service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

import model.MemberDAO;
import model.MemberDTO;

public class MemberService {
	MemberDAO mdao = new MemberDAO();
	
	//솔트생성
	public String saltmake() {
		String salt = null;
		try {
			SecureRandom srandom = SecureRandom.getInstance("SHA1PRNG");
			byte[] bytes = new byte[16];
			srandom.nextBytes(bytes);
			//Base64: byte 데이터를 String 형식으로 표시
			salt = new String(Base64.getEncoder().encode(bytes));
//			System.out.println("salt: " + salt);
//			System.out.println("salt 길이: " + salt.length());
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return salt;
	}
	
	//평문을 암호문으로 변경
	public String sha256(String passwd, String salt) {
		StringBuilder sb = null;
		try {
			//SHA-256:단방향 암호기법, 256bit
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(passwd.getBytes()); //문자열을 바이트 배열로 변경해서 전달
			md.update(salt.getBytes());

			byte[] data = md.digest();
//			System.out.println("암호화된 바이트 배열: " + Arrays.toString(data));
//			System.out.println("바이트 배열의 길이: " + data.length);
			
			//16진수 문자열로 변경
			sb = new StringBuilder();
			for(byte b : data) {
				sb.append(String.format("%02x", b)); //b:2 o:8 x:16
			}
//			System.out.println("암호화된 문자열: " + sb.toString());
//			System.out.println("암호 문자열의 길이: " + sb.length());
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		
		return sb.toString(); //암호문 반환
	}
	
	public int insert(MemberDTO mdto) {
		//암호화처리
		//솔트 생성, 암호화 전달
		String salt = saltmake();
		//평문pw + salt를 이용해서 암호문을 만든다
		String encryptpw =  sha256(mdto.getPasswd(), salt);
		mdto.setPasswd(encryptpw);
		mdto.setSalt(salt);
		System.out.println("insertservice:" + mdto);
		
		return mdao.insert(mdto);
	}
	
	//로그인체크
	public int loginCheck(String userId, String passwd) {
		//0: 성공 
		//1: 아이디불일치
		//2: 패스워드불일치
		
		//아이디를 가진 회원 조회
		MemberDTO mdto = mdao.selectOne(userId);
		System.out.println("service:" + mdto);
		if (mdto == null) {
			return 1;
		}else{
			//db의 암호화된 패스워드
			String dbpasswd = mdto.getPasswd();
			String salt = mdto.getSalt();
			System.out.println("loginCheck:dbpasswd:" + dbpasswd);
			System.out.println("loginCheck:salt:" + salt);
			//평문을 암호화한 패스워드
			//평문pw + salt를 이용해서 암호문을 만든다
			String encryptpw =  sha256(passwd, salt); 
			System.out.println("loginCheck:encryptpw:" + encryptpw);
			
			if (dbpasswd.equals(encryptpw)) {
				System.out.println("패스워드일치");
				return 0;
			}else {
				System.out.println("패스워드불일치");
				return 2;
			}
		}
	}
}
