package service;

import java.util.List;

import model.KeywordDAO;
import model.KeywordDTO;

public class KeywordService {
	KeywordDAO kdao = new KeywordDAO();
	public List<KeywordDTO> selectList(){
		return kdao.selectList();
	}
}
