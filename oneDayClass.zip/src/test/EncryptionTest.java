package test;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.catalina.tribes.util.Arrays;



public class EncryptionTest {
	//솔트생성
	static String saltmake() {
		String salt = null;
		try {
			SecureRandom srandom = SecureRandom.getInstance("SHA1PRNG");
			byte[] bytes = new byte[16];
			srandom.nextBytes(bytes);
			//Base64 : byte데이터를 String형식으로 표시
			salt = new String(Base64.getEncoder().encode(bytes));
			System.out.println("salt:"  + salt);
			System.out.println("salt길이:"  + salt.length());
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return salt;
	}
	
	//평문을 암호문으로 변경
	static Map<String,String> sha256(String passwd) {
		Map<String,String> result = new HashMap<>();
		StringBuilder sb = null;
		String salt = null;
		try {
			//SHA-256:단방향암호기법:256bit
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(passwd.getBytes()); //문자열을 바이트배열로 변경해서 전달
			//솔트생성 전달
			salt = EncryptionTest.saltmake();
			md.update(salt.getBytes());
			
			byte[] data = md.digest();
			System.out.println("암호화된 바이트배열:" + Arrays.toString(data)); 
			System.out.println("바이트배열길이:" + data.length);
			
			//16진수 문자열로 변경
			sb = new StringBuilder();
			for(byte b:data) {
				sb.append(String.format("%02x", b));
			}
			System.out.println("암호화된 문자열:" + sb.toString());
			System.out.println("암호문자열길이:" + sb.length());
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		result.put("encryptpw", sb.toString());
		result.put("salt", salt);
		
		return result;
		
	}
	public static void main(String[] args) {
		// sha-256암호화
		Map<String,String> result = EncryptionTest.sha256("1111");
		System.out.println("암호문:" + result.get("encryptpw"));
		System.out.println("솔트:" + result.get("salt"));
		
		
		
		
		
		

	}

}
