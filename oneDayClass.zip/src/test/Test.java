package test;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class Test {
	//솔트생성
	public static String saltmake() throws NoSuchAlgorithmException{
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
		byte[] bytes = new byte[16];
		random.nextBytes(bytes);
		String salt = new String(Base64.getEncoder().encode(bytes));
		System.out.println("salt:" + salt); 
		System.out.println("salt:" + salt.length()); 
		//솔트 db에 저장
		return salt;
	}
	
	public static String sha256(String msg)  throws NoSuchAlgorithmException {
	    MessageDigest md = MessageDigest.getInstance("SHA-256");
	    md.update(msg.getBytes());
	    
	    //솔트 생성
	    md.update(Test.saltmake().getBytes());
	    
	    byte[] data = md.digest();
	    
	    //문자열로 변경
	    StringBuilder sb = new StringBuilder();
	    for(byte b : data) {
	        sb.append(String.format("%02x",  b));
	    }
	    return sb.toString();
	}

	public static void main(String[] args) {
		// SHA-256
		try {
			String p2 = Test.sha256("1111");
			System.out.println(p2);
			System.out.println(p2.length());
		
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

	}

}
