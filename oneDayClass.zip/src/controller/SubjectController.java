package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import model.KeywordDTO;
import model.SubjectDTO;
import service.KeywordService;
import service.SubjectService;

@WebServlet("*.subject")
public class SubjectController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		System.out.println(uri);
		String path = request.getContextPath();
		SubjectService sService = new SubjectService(); 
		if (uri.indexOf("addForm") !=-1) {
			//등록 폼으로 이동
			//키워드 리스트 조회
			KeywordService kService = new KeywordService();
			List<KeywordDTO> kList = kService.selectList();
			System.out.println(kList);
			
			request.setAttribute("kList", kList);
			//등록 폼으로 이동
			request.getRequestDispatcher("/view/subject/add.jsp").forward(request, response);
			
		}else if (uri.indexOf("insert") != -1) {
			//saveDirectory : 서버의 파일을 저장할 디렉토리
			String saveDirectory = "D:/upload";
			//파일저장 최대 사이즈
			int size = 1024 * 1024 * 10; //10M
			//new DefaultFileRenamePolicy() : 동일 파일 존재 시, 파일 이름 변경
			MultipartRequest multi=
					new MultipartRequest(request, saveDirectory, size, "utf-8", new DefaultFileRenamePolicy());
			//데이터 읽기
			String subCode = multi.getParameter("subCode");
			String subName = multi.getParameter("subName");
			int price = Integer.parseInt(multi.getParameter("price"));
			String kwCode = multi.getParameter("kwCode");
			//실제 올라간 파일 이름
			String fileName = multi.getFilesystemName("fileName");
			
			SubjectDTO sdto = new SubjectDTO();
			sdto.setSubCode(subCode);
			sdto.setSubName(subName);
			sdto.setPrice(price);
			sdto.setFileName(fileName);
			sdto.setKwCode(kwCode);
			
			System.out.println("controller:"+ sdto);
			int cnt = sService.insert(sdto);
			System.out.println(cnt + "건 추가");
			
			//클래스 리스트 조회
                        response.sendRedirect(path + "/list.subject");
			
		}else if(uri.indexOf("list") != -1) {
		        String findValue = request.getParameter("findValue");
		        System.out.println(findValue);
		        Map<String,String> findMap = new HashMap<>();
		        findMap.put("findValue", findValue);
		        List<Map<String, Object>> subList = sService.selectList(findMap);
		        KeywordService kService = new KeywordService();
		        List<KeywordDTO> kList = kService.selectList();
		        request.setAttribute("subList", subList);
		        request.setAttribute("kList", kList);
		        request.getRequestDispatcher("/view/subject/list.jsp").forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
