package controller;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.MemberDTO;
import service.MemberService;

@WebServlet("*.member")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		System.out.println(uri);
		
		//서비스객체 생성
		MemberService mservice = new MemberService();
		String path = request.getContextPath();
		if (uri.indexOf("join") !=-1) {
			//회원가입
			String userId = request.getParameter("userId");
			String passwd = request.getParameter("passwd");
			String name = request.getParameter("name");
			MemberDTO mdto = new MemberDTO(userId,passwd,name);
			System.out.println("MemberController:" + mdto);
			
			mservice.insert(mdto);
			
			//로그인 창으로 이동
			response.sendRedirect(path+"/view/login/login.jsp");
			
		}else if (uri.indexOf("login") !=-1) {
			//로그인
			String userId = request.getParameter("userId");
			String passwd = request.getParameter("passwd");
			System.out.println("MemberController:" + userId + passwd);
			//0: 성공 
			//1: 아이디불일치
			//2: 패스워드불일치
			int result = mservice.loginCheck(userId, passwd);
			String msg = "";
	                msg = URLEncoder.encode(msg, "utf-8");
			if (result ==0) {
				msg = "성공";
				HttpSession session = request.getSession();
				session.setAttribute("userId", userId);
				session.setMaxInactiveInterval(60*60*2);
		                response.sendRedirect(path+"/view/home.jsp");
			}else if (result==1){
				msg = "아이디가 존재하지 않습니다.";
				request.setAttribute("msg", msg);
				response.sendRedirect(path+"/view/login/login.jsp");
			}else if (result==2){
				msg = "패스워드 불일치";
	                        request.setAttribute("msg", msg);
	                        response.sendRedirect(path+"/view/login/login.jsp");
			}

		
		}else if (uri.indexOf("logout") != -1) {
		        HttpSession session = request.getSession();
		        //세션 끊기
		        session.invalidate();
		        
		        response.sendRedirect(path+"/view/home.jsp");
		}
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
