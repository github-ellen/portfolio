package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.SalesDTO;
import service.SalesService;
import service.SubjectService;

@WebServlet("*.sales")
public class SalesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        
	        String uri = request.getRequestURI();
	        String path = request.getContextPath();
	        System.out.println(uri);
	        
	        SubjectService sService = new SubjectService();
	        SalesService salesService = new SalesService();
	        
	        if(uri.indexOf("apply") != -1) {
	                Map<String, String> findmap = new HashMap<>();
                        List<Map<String, Object>> sList = sService.selectList(findmap);
                        System.out.println(sList);
                        
                        request.setAttribute("sList", sList);
                        request.getRequestDispatcher("/view/sales/apply.jsp").forward(request, response);
	        
	        }else if(uri.indexOf("insert") != -1) {
	                String userId = request.getParameter("userId");
	                String subCode = request.getParameter("subCode");
	                String saleDate = request.getParameter("saleDate");
                        int cnt = Integer.parseInt(request.getParameter("cnt"));
                        int amount = Integer.parseInt(request.getParameter("amount"));
                        SalesDTO sdto= new SalesDTO();
                        sdto.setUserId(userId);
                        sdto.setSubCode(subCode);
                        sdto.setSaleDate(saleDate);
                        sdto.setCnt(cnt);
                        sdto.setAmount(amount);
                        System.out.println(sdto);
	                int count = salesService.insert(sdto);
	                String msg = count +"건 신청 완료";
	                request.setAttribute("msg", msg);
	                
	                request.getRequestDispatcher("/view/sales/apply.jsp").forward(request, response);
	        
	        }else if (uri.indexOf("listDetail") != -1) {
	                //검색 조건 구분
	                String findKey = request.getParameter("findKey");
	                String findValue = request.getParameter("findValue");
	                //System.out.println(findKey);
	                //System.out.println(findValue);
	                Map<String, String> findMap = new HashMap<>();
	                findMap.put("findKey", findKey);
	                findMap.put("findValue", findValue);
	                System.out.println("findMap : " + findMap);
	                List<Map<String, Object>> salesList = salesService.selectList(findMap);
	                request.setAttribute("salesList", salesList);
	                
	                request.getRequestDispatcher("/view/sales/listDetail.jsp").forward(request, response);
	        }
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
