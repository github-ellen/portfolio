package model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

public class SubjectDAO {
	public int insert(SubjectDTO sdto) {
		try(SqlSession session = MBConn.getSession()){
			return session.insert("SubjectMapper.insert", sdto);	
		}
	}

        public List<Map<String, Object>> selectList(Map<String, String> findMap) {
                try(SqlSession session = MBConn.getSession()){
                        return session.selectList("SubjectMapper.selectList", findMap);
                }
        }
}
