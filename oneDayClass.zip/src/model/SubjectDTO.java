package model;

public class SubjectDTO {
	private String subCode;
	private String subName;
	private int price;
	private String fileName;
	private String kwCode;
	
        public SubjectDTO() {
                super();
        }

        public SubjectDTO(String subCode, String subName, int price, String fileName, String kwCode) {
                super();
                this.subCode = subCode;
                this.subName = subName;
                this.price = price;
                this.fileName = fileName;
                this.kwCode = kwCode;
        }

        public String getSubCode() {
                return subCode;
        }

        public void setSubCode(String subCode) {
                this.subCode = subCode;
        }

        public String getSubName() {
                return subName;
        }

        public void setSubName(String subName) {
                this.subName = subName;
        }

        public int getPrice() {
                return price;
        }

        public void setPrice(int price) {
                this.price = price;
        }

        public String getFileName() {
                return fileName;
        }

        public void setFileName(String fileName) {
                this.fileName = fileName;
        }

        public String getKwCode() {
                return kwCode;
        }

        public void setKwCode(String kwCode) {
                this.kwCode = kwCode;
        }

        @Override
        public String toString() {
                return "SubjectDTO [subCode=" + subCode + ", subName=" + subName + ", price=" + price + ", fileName="
                                + fileName + ", kwCode=" + kwCode + "]";
        }
	
}
