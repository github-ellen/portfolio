package model;

import org.junit.jupiter.api.Test;

class JunitTest {
	@Test
	void sessiontest() {
		MBConn.getSession();
	}

}
