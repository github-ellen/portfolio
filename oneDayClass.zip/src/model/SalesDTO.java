package model;

public class SalesDTO {
	private int seq;
	private String saleDate;
	private String subCode;
	private String userId;
	private int cnt; //인원
	private int amount;
	
	public SalesDTO() {};
	
        public SalesDTO(String saleDate, String subCode, String userId, int cnt, int amount) {
                super();
                this.saleDate = saleDate;
                this.subCode = subCode;
                this.userId = userId;
                this.cnt = cnt;
                this.amount = amount;
        }

        public int getSeq() {
                return seq;
        }

        public void setSeq(int seq) {
                this.seq = seq;
        }

        public String getSaleDate() {
                return saleDate;
        }

        public void setSaleDate(String saleDate) {
                this.saleDate = saleDate;
        }

        public String getSubCode() {
                return subCode;
        }

        public void setSubCode(String subCode) {
                this.subCode = subCode;
        }

        public String getUserId() {
                return userId;
        }

        public void setUserId(String userId) {
                this.userId = userId;
        }

        public int getCnt() {
                return cnt;
        }

        public void setCnt(int cnt) {
                this.cnt = cnt;
        }

        public int getAmount() {
                return amount;
        }

        public void setAmount(int amount) {
                this.amount = amount;
        }

        @Override
        public String toString() {
                return "SalesDTO [seq=" + seq + ", saleDate=" + saleDate + ", subCode=" + subCode + ", userId=" + userId
                                + ", cnt=" + cnt + ", amount=" + amount + "]";
        }
	
}
