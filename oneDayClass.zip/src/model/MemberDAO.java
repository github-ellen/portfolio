package model;

import org.apache.ibatis.session.SqlSession;

public class MemberDAO {
	public int insert(MemberDTO mdto) {
		try(SqlSession session = MBConn.getSession()){
			return session.insert("MemberMapper.insert", mdto);
		}
	}
	
	public MemberDTO selectOne(String userId) {
		try(SqlSession session = MBConn.getSession()){
			return session.selectOne("MemberMapper.selectOne", userId);
		}
	}
}
