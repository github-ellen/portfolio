package model;

public class MemberDTO {
	private String userId;
	private String passwd;
	private String salt;
	private String name;
	private String regDate;
	
        public MemberDTO(String userId, String passwd, String name) {
                super();
                this.userId = userId;
                this.passwd = passwd;
                this.name = name;
        }
        public String getUserId() {
                return userId;
        }
        public void setUserId(String userId) {
                this.userId = userId;
        }
        public String getPasswd() {
                return passwd;
        }
        public void setPasswd(String passwd) {
                this.passwd = passwd;
        }
        public String getSalt() {
                return salt;
        }
        public void setSalt(String salt) {
                this.salt = salt;
        }
        public String getName() {
                return name;
        }
        public void setName(String name) {
                this.name = name;
        }
        public String getRegDate() {
                return regDate;
        }
        public void setRegDate(String regDate) {
                this.regDate = regDate;
        }
        @Override
        public String toString() {
                return "MemberDTO [userId=" + userId + ", passwd=" + passwd + ", salt=" + salt + ", name=" + name
                                + ", regDate=" + regDate + "]";
        }
	
}
