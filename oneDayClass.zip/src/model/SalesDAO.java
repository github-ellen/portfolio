package model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

public class SalesDAO {

	public int insert(SalesDTO sdto) {
		try(SqlSession session = MBConn.getSession()){
			return session.insert("SalesMapper.insert", sdto);
		}
	}

	public List<Map<String,Object>> selectList_detail(Map<String, String> findmap) {
		try(SqlSession session = MBConn.getSession()){
			return session.selectList("SalesMapper.selectList_detail", findmap);
		}
		
	}
	public List<Map<String,Object>> selectList(Map<String, String> findmap) {
		try(SqlSession session = MBConn.getSession()){
			return session.selectList("SalesMapper.selectList", findmap);
		}
		
	}

}
