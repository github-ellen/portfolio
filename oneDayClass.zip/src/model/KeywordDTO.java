package model;

public class KeywordDTO {
	private String kwCode;
	private String kwName;
	
        public KeywordDTO(String kwCode, String kwName) {
                super();
                this.kwCode = kwCode;
                this.kwName = kwName;
        }
        public String getKwCode() {
                return kwCode;
        }
        public void setKwCode(String kwCode) {
                this.kwCode = kwCode;
        }
        public String getKwName() {
                return kwName;
        }
        public void setKwName(String kwName) {
                this.kwName = kwName;
        }
        @Override
        public String toString() {
                return "KeywordDTO [kwCode=" + kwCode + ", kwName=" + kwName + "]";
        }

}
