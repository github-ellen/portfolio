package model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

public class KeywordDAO {
	public List<KeywordDTO> selectList(){
		try(SqlSession session = MBConn.getSession()){
			return session.selectList("KeywordMapper.selectList");
		}
	}
}
