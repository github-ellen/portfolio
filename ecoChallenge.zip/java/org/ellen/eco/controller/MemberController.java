package org.ellen.eco.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.ellen.eco.service.MemberService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("member")
public class MemberController {
	
	@Autowired
	private MemberService mService;
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@GetMapping("login")
	public void login() {}
	
	@PostMapping("login")
	public String login(String userId, String userPw, HttpSession session, Model model) throws Exception {
		Map<String, Object> map = mService.login(userId, userPw);
		System.out.println(map);
		if ((int)map.get("rCode") == 0) { //정보 일치
			session.setAttribute("userId", userId);
			return "redirect:/home/main";
		}
		else { //정보 불일치
			model.addAttribute("map", map);
			return "/member/login";
		}
	}
	
	@GetMapping("logout")
	public String logout(HttpSession session) {
		//세션 끊기.
		session.invalidate();
		return "redirect:/";
	}
	
	
}
