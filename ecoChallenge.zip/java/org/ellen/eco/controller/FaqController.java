package org.ellen.eco.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.ellen.eco.dto.Page;
import org.ellen.eco.service.FaqService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@RequestMapping("faq")
@SessionAttributes("page")
public class FaqController {

	@Autowired
	private FaqService faqService;
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@RequestMapping("/")
	public String list(Page page, Model model) throws Exception {
		model.addAttribute("page", page);
		return "redirect:faqList";
	}
	
	@GetMapping("faqList")
	public void boardList(@ModelAttribute("page") Page page, Model model) throws Exception{
		List<Map<String, Object>> faqList = faqService.selectList(page);
		model.addAttribute("page", page);
		model.addAttribute("faqList", faqList);
	}
	
	@GetMapping("faqDetail")
	public void detail(int bnum, Model model, HttpSession session) throws Exception{
		String userId = (String) session.getAttribute("userId");
		System.out.println(userId);
		//한 건 조회
		Map<String, Object> boardMap = faqService.selectOne(bnum, userId);
		model.addAttribute("boardMap", boardMap);
	}
	
}
