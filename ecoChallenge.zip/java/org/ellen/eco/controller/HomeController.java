package org.ellen.eco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("home")
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@GetMapping("signUp")
	public void signUp() {}
	
	//팝업창 호출에는 get으로,
	//callBack 호출은 POST방식으로 넘어오기 때문에
	@RequestMapping("jusoPopup")
	public void jusoPopup() {
	}
	
	@GetMapping("main")
	public void main() {}
}
