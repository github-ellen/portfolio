package org.ellen.eco.dto;

import java.util.Date;

import lombok.Data;

@Data
public class Faq {
	private int faqNum;
	private String userId;
	private String title;
	private String content;
	private Date regDate;
}
