package org.ellen.eco.dto;

import lombok.Data;

@Data
public class Member {
	private String userId;
	private String userPw;
	private int userBday;
	private int userPhone;
	private int ecoPoint;
}
