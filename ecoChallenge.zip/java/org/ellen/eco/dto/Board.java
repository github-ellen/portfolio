package org.ellen.eco.dto;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class Board {
	
	private String missionBoard; //소타이틀 출력용
	private String mission; //소타이틀 출력용
	private int boardNum;
	private String userId;
	private String content;
	private String fileName;
	private int readCnt;
	private int goodCnt;
	private String ip;
	private Date regDate;
	private Date modifyDate;
	
}
