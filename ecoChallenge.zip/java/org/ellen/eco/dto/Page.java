package org.ellen.eco.dto;

import lombok.Data;

@Data
public class Page {
	private String missionBoard; //미션 게시판 분류
	private int curPage = 1;
	private int perPage = 10; //한 페이지에 게시물 10개 보이기
	private int perBlock = 5;
	
	private int totalPage;
	private int startNum;
	private int endNum;
	private int startPage;
	private int endPage;
}
