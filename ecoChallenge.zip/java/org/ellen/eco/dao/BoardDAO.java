package org.ellen.eco.dao;

import java.util.List;
import java.util.Map;

import org.ellen.eco.dto.Board;
import org.ellen.eco.dto.Page;

public interface BoardDAO {
	public void insert(Board board);

	public List<Map<String, Object>> selectList(Page page);

	public List<Map<String, Object>>  readBoard(int boardNum);

	public int totalCnt(String missionBoard);


}
