package org.ellen.eco.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.ellen.eco.dto.Board;
import org.ellen.eco.dto.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAOImpl implements BoardDAO{
	
	@Autowired
	private SqlSession sql;
	
	public void insert(Board board) {
		sql.insert("org.ellen.eco.BoardMapper.insert", board);
	}

	@Override
	public List<Map<String, Object>> selectList(Page page) {
		return sql.selectList("org.ellen.eco.BoardMapper.selectList", page);
	}

	@Override
	public List<Map<String, Object>> readBoard(int boardNum) {
		return sql.selectList("org.ellen.eco.BoardMapper.readBoard", boardNum);
	}

	@Override
	public int totalCnt(String missionBoard) {
		return sql.selectOne("org.ellen.eco.BoardMapper.totalCnt", missionBoard);
	}
}
