package org.ellen.eco.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.ellen.eco.dto.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class FaqDAOImpl implements FaqDAO{

	@Autowired
	private SqlSession sql;
	
	@Override
	public int selectTotCnt(Page page) {
		return sql.selectOne("org.ellen.eco.FaqMapper.selectTotCnt", page);
	}

	@Override
	public List<Map<String, Object>> selectList(Page page) {
		return sql.selectList("org.ellen.eco.FaqMapper.selectList", page);
	}
}
