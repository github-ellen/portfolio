package org.ellen.eco.dao;


import org.ellen.eco.dto.Member;


public interface MemberDAO {

	public Member selectOne(String userId);
}
