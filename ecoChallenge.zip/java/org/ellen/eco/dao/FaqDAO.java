package org.ellen.eco.dao;

import java.util.List;
import java.util.Map;

import org.ellen.eco.dto.Page;

public interface FaqDAO {

	public int selectTotCnt(Page page);

	public List<Map<String, Object>> selectList(Page page);

}
