package org.ellen.eco.dao;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.ellen.eco.dto.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SqlSession sql;
	
	@Override
	public Member selectOne(String userId) {
		return sql.selectOne("org.ellen.eco.MemberMapper.selectOne", userId);
	}


}
