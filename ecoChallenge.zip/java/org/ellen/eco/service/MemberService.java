package org.ellen.eco.service;

import java.util.Map;

public interface MemberService {
	
	public Map<String, Object> login(String userId, String userPw);
}
