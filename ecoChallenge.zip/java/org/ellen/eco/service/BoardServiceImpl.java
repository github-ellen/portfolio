package org.ellen.eco.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ellen.eco.controller.BoardController;
import org.ellen.eco.dao.BoardDAO;
import org.ellen.eco.dto.Board;
import org.ellen.eco.dto.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class BoardServiceImpl implements BoardService {

	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	
	@Autowired
	private BoardDAO bDAO ;
	
	@Autowired
	private FileService fService ;
	
	@Override
	public void insert(Board board, MultipartFile photo) {
		String savedFileName = fService.fileUpload(photo);
		board.setFileName(savedFileName);
		logger.info(board.toString());
		bDAO.insert(board);
		
	}

	@Override
	public List<Map<String, Object>> selectList(Page page) {
		int totCnt = bDAO.totalCnt(page.getMissionBoard());
		//보여지는 페이지 수
		int totPage = totCnt / page.getPerPage();
		if (totCnt % page.getPerPage()!=0 ) {
			totPage += 1;
		}
		page.setTotalPage(totPage);
		//현재 페이지
		int curPage = page.getCurPage();
		
		//시작번호
		int startNum = (curPage-1) * page.getPerPage() + 1;
		page.setStartNum(startNum);
		
		//끝번호
		int endNum = startNum + page.getPerPage() -1;
		page.setEndNum(endNum);
		
		//시작페이지
		int startPage = curPage - ((curPage-1) %page.getPerBlock());
		page.setStartPage(startPage);
		
		//끝페이지
		int endPage = startPage + page.getPerBlock() -1;
		if (endPage > totPage) endPage = totPage;
		page.setEndPage(endPage);
		
		return bDAO.selectList(page);
	}

	@Override
	public List<Map<String, Object>> readBoard(int boardNum) {
		return bDAO.readBoard(boardNum);
	}




}
