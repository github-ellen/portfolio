package org.ellen.eco.service;

import java.util.List;
import java.util.Map;

import org.ellen.eco.dao.FaqDAO;
import org.ellen.eco.dto.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FaqServiceImpl implements FaqService {

	@Autowired
	private FaqDAO faqDAO;
	
	@Override
	public Map<String, Object> selectOne(int bnum, String userId) {
		return null;
	}

	@Override
	public List<Map<String, Object>> selectList(Page page) {
		int totCnt = faqDAO.selectTotCnt(page);
		System.out.println("faq 수 : " + totCnt);
		//한 페이지에 보여지는 페이지 수
		int totPage = totCnt / page.getPerPage();
		if (totCnt % page.getPerPage()!=0 ) totPage += 1;
		page.setTotalPage(totPage);
		
		//현재 페이지
		int curPage = page.getCurPage();
		//시작번호
		int startNum = (curPage-1) * page.getPerPage() + 1;
		page.setStartNum(startNum);
		
		int endNum = startNum + page.getPerPage() -1;
		page.setEndNum(endNum);
		
		int startPage = curPage - ((curPage-1) %page.getPerBlock());
		page.setStartPage(startPage);
		
		//끝페이지
		int endPage = startPage + page.getPerBlock() -1;
		//끝 페이지가 전체 페이지의 수보다 크면 안 되니까
		if (endPage > totPage) endPage = totPage;
		page.setEndPage(endPage);
		
		return faqDAO.selectList(page);
	}

	
}
