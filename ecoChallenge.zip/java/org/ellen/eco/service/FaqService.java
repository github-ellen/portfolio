package org.ellen.eco.service;

import java.util.List;
import java.util.Map;

import org.ellen.eco.dto.Page;

public interface FaqService {

	public Map<String, Object> selectOne(int bnum, String userId);

	public List<Map<String, Object>> selectList(Page page);

}
