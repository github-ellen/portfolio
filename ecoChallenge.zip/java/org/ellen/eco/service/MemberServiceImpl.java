package org.ellen.eco.service;

import java.util.HashMap;
import java.util.Map;

import org.ellen.eco.dao.MemberDAO;
import org.ellen.eco.dto.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDAO mDAO;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Override
	public Map<String, Object> login(String userId, String userPw) {
		Map<String, Object> resultMap = new HashMap<>();
		//0 : 로그인 완료, 1 : 아이디 미존재, 2 : 비번 불일치
		Member member = mDAO.selectOne(userId);
		int rCode;
		String msg = "";
		if (member == null) {
			rCode =  1;
			msg = "아이디가 존재하지 않습니다.";
		}
		else {
			//비밀번호 일치 여부 체크하기
			if (bCryptPasswordEncoder.matches(userPw, member.getUserPw())) {
				rCode = 0;
				msg = "로그인 완료";
			}
			else {
				rCode = 2;
				msg = "비밀번호를 확인해주세요.";
			}
			resultMap.put("rCode", rCode);
			resultMap.put("msg", msg);
		}
		return resultMap;
	}

}
