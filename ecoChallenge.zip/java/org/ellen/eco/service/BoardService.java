package org.ellen.eco.service;

import java.util.List;
import java.util.Map;

import org.ellen.eco.dto.Board;
import org.ellen.eco.dto.Page;
import org.springframework.web.multipart.MultipartFile;

public interface BoardService {

	public List<Map<String, Object>> selectList(Page page);

	public List<Map<String, Object>>  readBoard(int boardNum);

	public void insert(Board board, MultipartFile photo);


}
