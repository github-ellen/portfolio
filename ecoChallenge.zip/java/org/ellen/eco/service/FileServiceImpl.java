package org.ellen.eco.service;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

@Repository
public class FileServiceImpl implements FileService {

	@Autowired
	private String uploadDir;
	
	@Override
	public String fileUpload(MultipartFile photo) {
		
		String originName = photo.getOriginalFilename();
		String savedFileName = System.currentTimeMillis() +originName;
		System.out.println(savedFileName);
		
		File f = new File(uploadDir, savedFileName);
		try {
			photo.transferTo(f); //파일 업로드 완료
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return savedFileName;
	}

}
